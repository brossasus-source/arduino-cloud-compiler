// Wemos D1 mini + MAX7219 (2x2 modul)
// DIN -> D7, CLK -> D5, CS -> D8, VCC -> 5V, GND -> GND
#include "LedMatrix.h"

LedMatrix lm = LedMatrix(2, 2, 13, 14, 15);   // (satir, sutun, DIN=D7, CLK=D5, CS=D8)

void setup() {
  lm.setIntensity(1);
  lm.setFont(FONT8x8);
  lm.clearScreen();
  lm.setLed(1, 1, 1);
  lm.setLed(1, 2, 1);
  lm.update();
}

void loop() {
}
