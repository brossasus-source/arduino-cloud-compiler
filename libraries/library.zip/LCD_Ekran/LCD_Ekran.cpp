#include "LCD_Ekran.h"
#include <inttypes.h>
#include <Arduino.h>
#include <Wire.h>

// When the display powers up, it is configured as follows:
//
// 1. Display clear
// 2. Function set:
//    DL = 1; 8-bit interface data
//    N = 0; 1-line display
//    F = 0; 5x8 dot character font
// 3. Display on/off control:
//    D = 0; Display off
//    C = 0; Cursor off
//    B = 0; Blinking off
// 4. Entry mode set:
//    I/D = 1; Increment by 1
//    S = 0; No shift
//
// Note, however, that resetting the Arduino doesn't reset the LCD, so we
// can't assume that its in that state when a sketch starts (and the
// LiquidCrystal constructor is called).

LCD_Ekran::LCD_Ekran(uint8_t lcd_addr, uint8_t lcd_cols, uint8_t lcd_rows, uint8_t charsize)
{
    _addr = lcd_addr;
    _cols = lcd_cols;
    _rows = lcd_rows;
    _charsize = charsize;
    _backlightval = LCD_BACKLIGHT;
}

void LCD_Ekran::begin() {
    Wire.begin();
    _displayfunction = LCD_4BITMODE | LCD_1LINE | LCD_5x8DOTS;

    if (_rows > 1) {
        _displayfunction |= LCD_2LINE;
    }

    // for some 1 line displays you can select a 10 pixel high font
    if ((_charsize != 0) && (_rows == 1)) {
        _displayfunction |= LCD_5x10DOTS;
    }

    // SEE PAGE 45/46 FOR INITIALIZATION SPECIFICATION!
    // according to datasheet, we need at least 40ms after power rises above 2.7V
    // before sending commands. Arduino can turn on way befer 4.5V so we'll wait 50
    delay(50);

    // Now we pull both RS and R/W low to begin commands
    expanderWrite(_backlightval);    // reset expanderand turn backlight off (Bit 8 =1)
    delay(1000);

    //put the LCD into 4 bit mode
    // this is according to the hitachi HD44780 datasheet
    // figure 24, pg 46

    // we start in 8bit mode, try to set 4 bit mode
    write4bits(0x03 << 4);
    delayMicroseconds(4500); // wait min 4.1ms

    // second try
    write4bits(0x03 << 4);
    delayMicroseconds(4500); // wait min 4.1ms

    // third go!
    write4bits(0x03 << 4);
    delayMicroseconds(150);

    // finally, set to 4-bit interface
    write4bits(0x02 << 4);

    // set # lines, font size, etc.
    command(LCD_FUNCTIONSET | _displayfunction);

    // turn the display on with no cursor or blinking default
    _displaycontrol = LCD_DISPLAYON | LCD_CURSOROFF | LCD_BLINKOFF;
    display();

    // clear it off
    clear();

    // Initialize to default text direction (for roman languages)
    _displaymode = LCD_ENTRYLEFT | LCD_ENTRYSHIFTDECREMENT;

    // set the entry mode
    command(LCD_ENTRYMODESET | _displaymode);
    
    // türkçe custom karakter mapleri; "ü" ve "ö" hali hazırda var
      byte h0[8] =  {0, 14, 16, 14, 1, 30, 4, 0};     // Ş - ş
      byte h1[8] =  {0, 14, 17, 16, 17, 14, 4, 0};    // ç
      byte h2[8] =  {0, 0, 12, 4, 4, 4, 14, 0};       // ı
      byte h3[8] =  {4, 0, 14, 4, 4, 4, 14, 0};       // İ
      byte h4[8] =  {14, 0, 14, 18, 14, 2, 28, 0};    // ğ
      byte h5[8] =  {14, 0, 14, 16, 22, 18, 14, 0};   // Ğ
      byte h6[8] =  {14, 17, 16, 16, 16, 17, 14, 4};  // Ç
      byte h7[8] =  {10, 0, 17, 17, 17, 17, 14, 0};   // Ü

      createChar(0, h0);
      createChar(1, h1);
      createChar(2, h2);
      createChar(3, h3);
      createChar(4, h4);
      createChar(5, h5);
      createChar(6, h6);
      createChar(7, h7);
      clear();

    home();
}

/********** high level commands, for the user! */
void LCD_Ekran::clear(){
    command(LCD_CLEARDISPLAY);// clear display, set cursor position to zero
    delayMicroseconds(2000);  // this command takes a long time!
}

void LCD_Ekran::home(){
    command(LCD_RETURNHOME);  // set cursor position to zero
    delayMicroseconds(2000);  // this command takes a long time!
}

void LCD_Ekran::setCursor(uint8_t col, uint8_t row){
    int row_offsets[] = { 0x00, 0x40, 0x14, 0x54 };
    if (row > _rows) {
        row = _rows-1;    // we count rows starting w/0
    }
    command(LCD_SETDDRAMADDR | (col + row_offsets[row]));
}

// Turn the display on/off (quickly)
void LCD_Ekran::noDisplay() {
    _displaycontrol &= ~LCD_DISPLAYON;
    command(LCD_DISPLAYCONTROL | _displaycontrol);
}
void LCD_Ekran::display() {
    _displaycontrol |= LCD_DISPLAYON;
    command(LCD_DISPLAYCONTROL | _displaycontrol);
}

// Turns the underline cursor on/off
void LCD_Ekran::noCursor() {
    _displaycontrol &= ~LCD_CURSORON;
    command(LCD_DISPLAYCONTROL | _displaycontrol);
}
void LCD_Ekran::cursor() {
    _displaycontrol |= LCD_CURSORON;
    command(LCD_DISPLAYCONTROL | _displaycontrol);
}

// Turn on and off the blinking cursor
void LCD_Ekran::noBlink() {
    _displaycontrol &= ~LCD_BLINKON;
    command(LCD_DISPLAYCONTROL | _displaycontrol);
}
void LCD_Ekran::blink() {
    _displaycontrol |= LCD_BLINKON;
    command(LCD_DISPLAYCONTROL | _displaycontrol);
}

// These commands scroll the display without changing the RAM
void LCD_Ekran::scrollDisplayLeft(void) {
    command(LCD_CURSORSHIFT | LCD_DISPLAYMOVE | LCD_MOVELEFT);
}
void LCD_Ekran::scrollDisplayRight(void) {
    command(LCD_CURSORSHIFT | LCD_DISPLAYMOVE | LCD_MOVERIGHT);
}

// This is for text that flows Left to Right
void LCD_Ekran::leftToRight(void) {
    _displaymode |= LCD_ENTRYLEFT;
    command(LCD_ENTRYMODESET | _displaymode);
}

// This is for text that flows Right to Left
void LCD_Ekran::rightToLeft(void) {
    _displaymode &= ~LCD_ENTRYLEFT;
    command(LCD_ENTRYMODESET | _displaymode);
}

// This will 'right justify' text from the cursor
void LCD_Ekran::autoscroll(void) {
    _displaymode |= LCD_ENTRYSHIFTINCREMENT;
    command(LCD_ENTRYMODESET | _displaymode);
}

// This will 'left justify' text from the cursor
void LCD_Ekran::noAutoscroll(void) {
    _displaymode &= ~LCD_ENTRYSHIFTINCREMENT;
    command(LCD_ENTRYMODESET | _displaymode);
}

// Allows us to fill the first 8 CGRAM locations
// with custom characters
void LCD_Ekran::createChar(uint8_t location, uint8_t charmap[]) {
    location &= 0x7; // we only have 8 locations 0-7
    command(LCD_SETCGRAMADDR | (location << 3));
    for (int i=0; i<8; i++) {
        write(charmap[i]);
    }
}

// Turn the (optional) backlight off/on
void LCD_Ekran::noBacklight(void) {
    _backlightval=LCD_NOBACKLIGHT;
    expanderWrite(0);
}

void LCD_Ekran::backlight(void) {
    _backlightval=LCD_BACKLIGHT;
    expanderWrite(0);
}
bool LCD_Ekran::getBacklight() {
  return _backlightval == LCD_BACKLIGHT;
}


/*********** mid level commands, for sending data/cmds */

inline void LCD_Ekran::command(uint8_t value) {
    send(value, 0);
}

inline size_t LCD_Ekran::write(uint8_t value) {
    send(value, Rs);
    return 1;
}


/************ low level data pushing commands **********/

// write either command or data
void LCD_Ekran::send(uint8_t value, uint8_t mode) {
    uint8_t highnib=value&0xf0;
    uint8_t lownib=(value<<4)&0xf0;
    write4bits((highnib)|mode);
    write4bits((lownib)|mode);
}

void LCD_Ekran::write4bits(uint8_t value) {
    expanderWrite(value);
    pulseEnable(value);
}

void LCD_Ekran::expanderWrite(uint8_t _data){
    Wire.beginTransmission(_addr);
    Wire.write((int)(_data) | _backlightval);
    Wire.endTransmission();
}

void LCD_Ekran::pulseEnable(uint8_t _data){
    expanderWrite(_data | En);    // En high
    delayMicroseconds(1);        // enable pulse must be >450ns

    expanderWrite(_data & ~En);    // En low
    delayMicroseconds(50);        // commands need > 37us to settle
}

void LCD_Ekran::load_custom_character(uint8_t char_num, uint8_t *rows){
    createChar(char_num, rows);
}

void LCD_Ekran::setBacklight(uint8_t new_val){
    if (new_val) {
        backlight();        // turn backlight on
    } else {
        noBacklight();        // turn backlight off
    }
}

void LCD_Ekran::printstr(const char c[]){
    //This function is not identical to the function used for "real" I2C displays
    //it's here so the user sketch doesn't have to be changed
    print(c);
}

// --- YENİ EKLENEN TÜRKÇE YAZDIRMA FONKSİYONU ---
void LCD_Ekran::printTr(String metin) {
    for (unsigned int i = 0; i < metin.length(); i++) {
        unsigned char c = metin[i];
        
        if (c < 128) {
            write(c);
        } else {
            i++; 
            if (i >= metin.length()) break; 
            unsigned char c2 = metin[i];
            
            if (c == 0xC3) {
                if (c2 == 0x87) write(6);       // Ç
                else if (c2 == 0xA7) write(1);  // ç
                else if (c2 == 0x9C) write(7);  // Ü
                else if (c2 == 0xBC) write(0xF5); // ü
                else if (c2 == 0x96) print("O");  // Ö
                else if (c2 == 0xB6) write(0xEF); // ö
            } else if (c == 0xC4) {
                if (c2 == 0x9E) write(5);       // Ğ
                else if (c2 == 0x9F) write(4);  // ğ
                else if (c2 == 0xB0) write(3);  // İ
                else if (c2 == 0xB1) write(2);  // ı
            } else if (c == 0xC5) {
                if (c2 == 0x9E || c2 == 0x9F) write(0); // Ş ve ş
            }
        }
    }
}