#include "HCSR04.h"

HCSR04 hc(5, 6); //trig,echo



void setup() {
  Serial.begin(9600);
  

}


void loop() {
 Serial.println(hc.dist());
 delay(100);
}
