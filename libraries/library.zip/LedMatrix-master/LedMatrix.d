C:\Users\ugco\mblock-avr\temp\build\LedMatrix-master\LedMatrix.o: \
 C:\Users\ugco\mblock-avr\temp\build\LedMatrix-master\LedMatrix.cpp \
 C:\Users\ugco\mblock-avr\temp\build\LedMatrix-master\LedMatrix.h \
 avr-library/cores/arduino/Arduino.h avr-library/cores/arduino/binary.h \
 avr-library/cores/arduino/WCharacter.h \
 avr-library/cores/arduino/WString.h \
 avr-library/cores/arduino/HardwareSerial.h \
 avr-library/cores/arduino/Stream.h avr-library/cores/arduino/Print.h \
 avr-library/cores/arduino/Printable.h avr-library/cores/arduino/USBAPI.h \
 avr-library/cores/arduino/Arduino.h \
 C:\Users\Public\Programs\mblock\resources\ml\v1\external\arduino\avr-library\variants\standard/pins_arduino.h \
 C:\Users\ugco\mblock-avr\temp\build\LedMatrix-master\font_5x7_col.h \
 C:\Users\ugco\mblock-avr\temp\build\LedMatrix-master\font_8x8_col.h
